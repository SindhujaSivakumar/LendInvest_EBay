package stepDefinitions;

import java.util.List;

import org.openqa.selenium.WebElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Ebay;
import pageObjects.ParentPage;

public class Scenario1 extends ParentPage {
	
	@Given("I am a non-registered customer")
	public void givenUser() {
		System.out.println("Non registered User");
	}
	
	@Given("I navigate to www.ebay.co.uk")
	public void launchurl() {
		launchEbay();
	}
		
	@When("I search for an item")
	public void itemsearch() {
		searchItem("iphone 13 pro max");
	}
		
	@Then("I get a list of matching results")
	public void resultcheck() {
		checkResults("iphone 13 pro max");
	}
		
	@Then("the resulting items cards show: postage price, No of bids, price or show BuyItNow tag")
	public void checkResultItemCards() {
		//Getting the postage details as list of elements
		List<WebElement> postage = driver.findElements(Ebay.postage_details);
		int postagecount = 0;
		//Traversing all the elements in the list and checking if postage details are present and incrementing the postage count
		for (int i=0;i<postage.size();i++) {
			if (postage.get(i).getText().contains("postage")) {
				postagecount=postagecount+1;
			}
		}
		//Getting the price details as list of elements
		List<WebElement> price = driver.findElements(Ebay.price_list);
		int pricecount = 0;
		//Traversing all the elements in the list and checking if price details are present and incrementing the price count
		for (int i=0;i<price.size();i++) {
			if (price.get(i).getText().contains("�")) {
				pricecount=pricecount+1;
			}
		}
		//Getting the buy it now details as list of elements
		List<WebElement> buynow = driver.findElements(Ebay.buy_it_now);
		int buynowcount = 0;
		//Traversing all the elements in the list and checking if Buy it now is present and incrementing the BuyItNow count
		for (int i=0;i<buynow.size();i++) {
			if (buynow.get(i).getText().contains("Buy")) {
				buynowcount=buynowcount+1;
			}
		}
		
		//Checking if all the count values are greater than 0
		if (postagecount>0 && pricecount>0 && buynowcount>0) {
			System.out.println("Postage, Price and Buy it now details displayed");
		}
		
	}
	
	@When("I sort the results by Lowest Price")
	public void sortLowestprice() {
		sort("Lowest price");
	}
	
	@Then("the results are listed in the page in the correct order from lowest to highest")
	public void ascendingOrder() {
		//Getting the price details as list of elements
		List<WebElement> pricelist = driver.findElements(Ebay.price_list);
		//Removing the � symbol from price
		String strprice1 = pricelist.get(0).getText().replace("�", "");
		String strprice2 = pricelist.get(1).getText().replace("�", "");
		//Removing the , symbol from price
		strprice1 = strprice1.replace(",", "");
		strprice2 = strprice2.replace(",", "");
		//Converting the price details from String to Double
		double price1 = Double.parseDouble(strprice1);
		double price2 = Double.parseDouble(strprice2);
		//Verifying if Price 1 is less than Price 2
		if(price1<price2) {
			System.out.println("Items sorted based on Lowest Price");
		}
	}
	
	@When("I sort the results by Highest Price")
	public void sortHighestprice() {
		sort("Highest price");
	}
	
	@Then("the results are listed in the page in the correct order from highest to lowest")
	public void descendingOrder() {
		//Getting the price details as list of elements
		List<WebElement> pricelist = driver.findElements(Ebay.price_list);
		//Removing the � symbol from price
		String strprice1 = pricelist.get(0).getText().replace("�", "");
		String strprice2 = pricelist.get(1).getText().replace("�", "");
		//Removing the , symbol from price
		strprice1 = strprice1.replace(",", "");
		strprice2 = strprice2.replace(",", "");
		//Converting the price details from String to Double
		double price1 = Double.parseDouble(strprice1);
		double price2 = Double.parseDouble(strprice2);
		//Verifying if Price 1 is greater than Price 2
		if(price1>price2) {
			System.out.println("Items sorted based on Highest Price");
		}
	}
	
	
}
