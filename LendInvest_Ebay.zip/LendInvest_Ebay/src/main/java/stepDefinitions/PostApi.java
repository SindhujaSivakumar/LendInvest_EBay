package stepDefinitions;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.*;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostApi {
	@Test
	public void testPostResponse() {
		//Specifying the request body attributes
		RequestSpecification request = RestAssured.given();
		request.header("Content-Type","application/json");
		
		JSONObject json = new JSONObject();
		json.put("id", "1842347-1560779940");
		json.put("cost", "�829.99");
		json.put("location", "PAC");
		
		request.body(json.toJSONString());
		
		//getting response for REST API POST request
		Response res = request.post("https://localhost/location/post");
		//Getting response code
		int code = res.getStatusCode();
		//Validating the response code
		Assert.assertEquals(code,200);
	}
}
