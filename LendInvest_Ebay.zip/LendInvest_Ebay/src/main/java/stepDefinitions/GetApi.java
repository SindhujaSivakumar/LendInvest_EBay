package stepDefinitions;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.*;
import io.restassured.response.Response;

public class GetApi {
	@Test
	public void testGetResponse() {
		//getting response for REST API GET request
		Response res = RestAssured.get("https://localhost/location/get/all");
		//Getting response code
		int code = res.getStatusCode();
		//Getting response data
		String data = res.asString();
		//Printing the response Data
		System.out.println("Data is: "+data);
		//Validating the response code
		Assert.assertEquals(code,200);
	}
}
