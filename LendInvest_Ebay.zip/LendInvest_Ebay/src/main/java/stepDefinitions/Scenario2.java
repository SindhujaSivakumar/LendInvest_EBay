package stepDefinitions;

import org.testng.annotations.AfterMethod;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.ParentPage;

public class Scenario2 extends ParentPage {

	@Given("Sc2-I am a non-registered customer")
	public void givenUser() {
		
	}
	
	@Given("Sc2-I navigate to www.ebay.co.uk")
	public void launchurl() {
		launchEbay();
	}
	
	@When("Sc2-I search for an item")
	public void itemsearch() {
		searchItem("iphone 13 pro max");
	}	
	
	@Then("Sc2-I get a list of matching results")
	public void resultcheck() {
		checkResults("iphone 13 pro max");
	}
	
	@Then("Sc2-the results show more than one page")
	public void morepages() {
		checkMorePagesDisplayed();
	}

	@Then("Sc2-the user can navigate through the pages to continue looking at the items")
	public void navigatepages() {
		pageNavigate(2, "iphone 13 pro max");
	}
	
	@AfterMethod
	public void postCondition() {
		browserClose();
	}

}
