package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ParentPage {
	
	public static ChromeDriver driver;

	//Method for launching the url and check if the correct webpage is displayed
	public static void launchEbay() {
		//initiating ChromeDriver
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//Launching Ebay url
		driver.get("https://www.ebay.co.uk/");
		//Verifying if EBay logo is displayed
		boolean logo = driver.findElement(By.id("gh-logo")).isDisplayed();
		if (logo) {
			System.out.println("Ebay Homepage is displayed");
		}
		else {
			System.out.println("Ebay Homepage is not displayed");
		}
	}
	
	//Method for entering the search item and clicking Search button
	public static void searchItem(String itemName) {
		driver.findElement(Ebay.search_text).sendKeys(itemName);
		driver.findElement(Ebay.search_button).click();
	}
	
	
	public static void checkResults(String itemName) {
		//validating if the search results are valid
		List<WebElement> searchResults = driver.findElements(Ebay.search_results);
		Assert.assertEquals(searchResults.get(1).getText(),itemName);
	}
	

	//Method for selecting the sorting option based on the given parameter
	public static void sort(String sortBy) {
		driver.findElement(Ebay.sort_dropdown_btn).click();
		List<WebElement> allOptions = driver.findElements(Ebay.sort_option_list);
		for(int i = 0; i<=allOptions.size()-1; i++) {
			if(allOptions.get(i).getText().equalsIgnoreCase(sortBy)) {     
				allOptions.get(i).click();
				break;          
			}
		}
	}
	
	//Method to Check if more than one page of results are displayed
	public static void checkMorePagesDisplayed() {

		if (driver.findElement(Ebay.next_page_btn).isEnabled()) {
			System.out.println("The results are displayed more than one page");
		}
	}
	
	//Method to navigate to next pages and validate the displayed items
	public static void pageNavigate(int num,String itemName) {
		for (int i=1;i<=num;i++) {
			driver.findElement(Ebay.next_page_btn).click();
			List<WebElement> searchResults = driver.findElements(Ebay.search_results);		
			Assert.assertEquals(searchResults.get(1).getText(),itemName);
		}
	}
	
	//Method to close the browser
	public static void browserClose() {
		driver.close();
	}
	
}
