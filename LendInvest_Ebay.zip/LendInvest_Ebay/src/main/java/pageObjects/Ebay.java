package pageObjects;

import org.openqa.selenium.By;

public class Ebay {
	//Search text box and Search Button
	public static By search_text=By.id("gh-ac");
	public static By search_button=By.id("gh-btn");
	
	//No of search results and searched product name
	public static By search_results=By.xpath("//div[@class='srp-controls__control srp-controls__count']//h1//span");
	public static By postage_details=By.xpath("//div//span//span[@class='POSITIVE BOLD']");
	public static By price_list=By.xpath("//ul[@class='srp-results srp-list clearfix']//li//div//div//span[@class='s-item__price']");
	public static By buy_it_now=By.xpath("//div//span[@class='s-item__purchase-options-with-icon']");
	
	//Sort button
	public static By sort_dropdown_btn=By.className("expand-btn__cell");
	public static By sort_option_list=By.xpath("//span[@class='fake-menu-button srp-controls__control']//ul[@class='fake-menu__items']//li");
	
	//Next page button
	public static By next_page_btn=By.xpath("//nav//a[@class='pagination__next icon-link']");
		
}
