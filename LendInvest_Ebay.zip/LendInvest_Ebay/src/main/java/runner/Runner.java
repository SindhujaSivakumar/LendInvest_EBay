package runner;

import org.testng.annotations.AfterMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import pageObjects.ParentPage;

public class Runner {

	@CucumberOptions(features = "src/main/java/features", 
					 glue = "stepDefinitions",
					 monochrome = true,
					 publish = true)
	public class CucumberRunner extends AbstractTestNGCucumberTests {
		@AfterMethod
		public void postCondition() {
			ParentPage.browserClose();
		}
	}


}
